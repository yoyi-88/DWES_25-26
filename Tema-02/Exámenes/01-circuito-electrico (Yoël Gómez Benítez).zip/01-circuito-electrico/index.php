<?php

/*

    Controlador: index.php
    Descripción: controlador principal del proyecto
    Examen Práctico: Tema 2. Insercióon de código PHP en HTML
    Autor: Yoël Gómez Benítez
    Fecha: 16/10/2025

*/

require_once "models/index.model.php";

require_once "views/index.view.php";


?>