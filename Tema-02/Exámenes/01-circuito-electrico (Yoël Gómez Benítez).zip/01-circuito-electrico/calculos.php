<?php

/*

    Controlador: calculos.php
    Descripción: controlador de los calculos y resultado del proyecto
    Examen Práctico: Tema 2. Inserción de código PHP en HTML
    Autor: Yoël Gómez Benítez
    Fecha: 16/10/2025

*/

require_once "models/calculos.model.php";

require_once "views/resultado.view.php";


?>