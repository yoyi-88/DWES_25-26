<?php
/*
Descripcion: Ordenar libros
*/

// Incluir librerías
include 'libs/functions.php';

// Cargar modelo 
require_once 'models/orden.model.php';

// Cargamos la vista
require_once 'views/index.view.php';

?>