<?php
/*
Actividad 3.3
Controlador: Principal
Descripcion: Declarar una tabla libros, array principal indexado y array secundario asociativo
*/

// Incluir librerías
include 'libs/functions.php';

// Cargar modelo
require_once 'models/index.model.php';

// Cargamos la vista
require_once 'views/index.view.php';

?>