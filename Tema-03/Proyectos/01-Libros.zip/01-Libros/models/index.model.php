<?php
/*
Descripcion: Modelo que contiene la tabla libros
*/

$libros = get_tabla_libros();




?>