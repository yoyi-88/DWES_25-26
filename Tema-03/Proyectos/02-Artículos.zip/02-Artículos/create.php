<?php

    /*
        Controlador para mostrar ventana para añadir libros
    */
    include 'libs/funciones.php';

    include 'models/create.model.php';

    include 'views/index.view.php';

?>