<?php

    /*
        Actualiza el articulo en el index.view.php
    */
    include 'libs/funciones.php';

    include 'models/update.model.php';

    include 'views/index.view.php';

?>