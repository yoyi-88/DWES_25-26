<?php

    /*
        Muestra datos de articulo a editar en un formulario editable
    */
    include 'libs/funciones.php';

    include 'models/edit.model.php';

    include 'views/edit.view.php';

?>