<?php

    /*
        Ordena segun el criterio seleccionado en index.view.php
    */
    include 'libs/funciones.php';

    include 'models/order.model.php';

    include 'views/index.view.php';

?>