<?php
/*
    Crea el array articulos y categorias para usar en el view
*/

$articulos = get_tabla_articulos();

$categorias = get_tabla_categorias();



?>