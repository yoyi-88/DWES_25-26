<?php

    /*
        Controlador principal de index
    */
    include 'libs/funciones.php';

    include 'models/index.model.php';

    include 'views/index.view.php';

?>