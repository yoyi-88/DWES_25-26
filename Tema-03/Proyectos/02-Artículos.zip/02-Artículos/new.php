<?php

    /*
        Controlador para mostrar ventana para añadir libros
    */
    include 'libs/funciones.php';

    include 'models/new.model.php';

    include 'views/new.view.php';

?>