<?php

    /*
        Controlador para mostrar ventana para añadir libros
    */
    include 'libs/funciones.php';

    include 'models/delete.model.php';

    include 'views/index.view.php';

?>