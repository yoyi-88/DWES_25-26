<?php

    /*
        Busca el campo en el index.view.php
    */
    include 'libs/funciones.php';

    include 'models/search.model.php';

    include 'views/index.view.php';

?>