<?php

    /*
        Busca el campo en el index.view.php
    */
    include 'libs/funciones.php';

    include 'models/show.model.php';

    include 'views/show.view.php';

?>