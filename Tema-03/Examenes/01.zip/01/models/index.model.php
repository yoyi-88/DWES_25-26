<?php
/* 
    
*/


$peliculas = get_tabla_peliculas();

?>