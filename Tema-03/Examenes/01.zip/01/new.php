<?php
/* 
    Controlador para añadir libros
*/

include 'libs/functions.php';

// El model no es necesario: include 'models/new.model.php';

include 'views/new.view.php';





?>