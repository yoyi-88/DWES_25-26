<?php
/* 
    Controlador para añadir libros
*/

include 'libs/functions.php';

include 'models/create.model.php';

include 'views/index.view.php';





?>