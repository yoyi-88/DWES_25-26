<?php
/* 
    Controlador principal del proyecto
*/

include 'libs/functions.php';

include 'models/delete.model.php';

include 'views/index.view.php';





?>