<footer class="footer mt-auto py-3 fixed-bottom bg-light">
    <div class="container">
        <span class="text-muted">&copy; 2025
            Juan Carlos Moreno - DWES - 2º DAW - Curso 25/26</span>
    </div>
</footer>