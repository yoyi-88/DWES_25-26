<?php
/* 
    Controlador para editar peliculas
*/

include 'libs/functions.php';

include 'models/show.model.php';

include 'views/show.view.php';





?>