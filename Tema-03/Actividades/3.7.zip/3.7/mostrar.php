<?php
/*
    Descripción: Mostrar detalles de un libro
*/

// Incluir librerías
include 'libs/functions.php';

include "models/mostrar.model.php";

include "views/view.form_mostrar.php";

?>