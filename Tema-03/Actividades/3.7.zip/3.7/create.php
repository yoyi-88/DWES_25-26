<?php
/*
Actividad 3.3
Controlador: create.php
Descripcion: Añadir libros al array y mostrar la tabla actualizada
*/
// Incluir librerías
include 'libs/functions.php';
// Cargar modelo (Si es necesario)
require_once 'models/create.model.php';

// Cargamos la vista
require_once 'views/index.view.php';

?>