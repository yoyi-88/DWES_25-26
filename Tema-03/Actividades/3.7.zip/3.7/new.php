<?php
/*
Actividad 3.3
Controlador: new.php
Descripcion: Añadir libros
*/

// Incluir librerías
include 'libs/functions.php';

// Cargar modelo (Si es necesario)
//require_once 'models/new.model.php';

// Cargamos la vista
require_once 'views/new.view.php';

?>