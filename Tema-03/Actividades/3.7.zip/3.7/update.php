<?php
/*
    Actualizar libro
*/

// Incluir librerías
include 'libs/functions.php';

include 'models/update.model.php';

include 'views/index.view.php';


?>


