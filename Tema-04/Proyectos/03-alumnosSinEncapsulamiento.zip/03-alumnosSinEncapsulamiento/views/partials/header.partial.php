<header class="pb-3 mb-4 border-bottom">
    <span class="fs-1">Proyecto 3.2 Tema 3 PHP</span>
    <h4>Gestión tabla artículos</h4>
</header>