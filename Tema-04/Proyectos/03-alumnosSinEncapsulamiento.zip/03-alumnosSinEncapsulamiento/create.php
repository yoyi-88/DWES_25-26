<?php

    /*
        Añade un nuevo artículo a partir del formulario new
    */

    // Incluir clase articulos
    require_once 'class/alumno.class.php';
    require_once 'class/tabla_alumnos.class.php';

    // Modelo
    require_once 'models/create.model.php';

    // Vista
    include 'views/index.view.php';






?>