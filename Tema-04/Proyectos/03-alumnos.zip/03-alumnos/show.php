<?php 
/* 
Controlador que muestra en un formulario editable los detalles de un artículo
*/


// incluir clases necesarias
require_once 'class/alumno.class.php';
require_once 'class/tabla_alumnos.class.php';

// Incluir el modelo
require_once 'models/show.model.php';

// incluir la vista
require_once 'views/show.view.php';

?>