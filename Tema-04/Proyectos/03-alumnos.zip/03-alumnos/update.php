<?php 
/* 
Actualiza los detalles de un artículo a partir del doemulario editable
*/


// incluir clases necesarias
require_once 'class/alumno.class.php';
require_once 'class/tabla_alumnos.class.php';

// Incluir el modelo
require_once 'models/update.model.php';

// incluir la vista
require_once 'views/index.view.php';

?>