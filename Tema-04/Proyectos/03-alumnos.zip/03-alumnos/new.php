<?php 
/* 
Muestra el formulario para crear un nuevo artículo
*/


// iincluir clases necesarias
require_once 'class/alumno.class.php';
require_once 'class/tabla_alumnos.class.php';

// Incluir el modelo
require_once 'models/new.model.php';

// incluir la vista
require_once 'views/new.view.php';

?>